import React, { useState, useEffect } from 'react';

function App() {
  // Состояние для позиции автомобилей
  const [blueCarPosition, setBlueCarPosition] = useState(-100);
  const [redCarPosition, setRedCarPosition] = useState(window.innerWidth + 100);

  // Анимация движения автомобилей
  useEffect(() => {
    const interval = setInterval(() => {
      // Обновляем позицию синего автомобиля (слева направо)
      setBlueCarPosition(prev => {
        const newPos = prev + 5;
        return newPos > window.innerWidth + 100 ? -100 : newPos;
      });
      
      // Обновляем позицию красного автомобиля (справа налево)
      setRedCarPosition(prev => {
        const newPos = prev - 5;
        return newPos < -100 ? window.innerWidth + 100 : newPos;
      });
    }, 30);
    
    return () => clearInterval(interval);
  }, []);

  // Стили для контейнера
  const containerStyle = {
    backgroundColor: '#FFA500', // Оранжевый фон
    width: '100%',
    height: '100vh',
    position: 'relative',
    overflow: 'hidden',
  };

  // Стили для дороги
  const roadStyle = {
    position: 'absolute',
    bottom: '20%',
    width: '100%',
    height: '30%',
    backgroundColor: '#555',
  };

  // Стили для разметки полос
  const roadMarkingsStyle = {
    position: 'absolute',
    bottom: '30%',
    width: '200%',
    height: '4px',
    backgroundColor: 'white',
    left: 0,
  };

  // Базовые стили для автомобиля
  const baseCarStyle = {
    position: 'absolute',
    bottom: '25%',
    width: '100px',
    height: '50px',
  };

  // Стили для синего автомобиля
  const blueCarStyle = {
    ...baseCarStyle,
    left: `${blueCarPosition}px`,
  };

  // Стили для красного автомобиля
  const redCarStyle = {
    ...baseCarStyle,
    left: `${redCarPosition}px`,
  };

  // Стили для колес
  const wheelStyle = {
    position: 'absolute',
    width: '20px',
    height: '20px',
    backgroundColor: 'black',
    borderRadius: '50%',
    bottom: '-5px',
  };

  // Стили для фар
  const headlightStyle = (isLeft) => ({
    position: 'absolute',
    width: '10px',
    height: '10px',
    backgroundColor: 'white',
    borderRadius: '50%',
    top: '15px',
    left: isLeft ? '5px' : 'auto',
    right: isLeft ? 'auto' : '5px',
  });

  return (
    <div style={containerStyle}>
      <div style={roadStyle}>
        {/* Разметка полос */}
        <div style={roadMarkingsStyle}></div>
        <div style={{...roadMarkingsStyle, marginTop: '15%'}}></div>
      </div>
      
      {/* Синий автомобиль (движется вправо) */}
      <div style={blueCarStyle}>
        <div style={{...baseCarStyle, backgroundColor: 'blue', borderRadius: '5px'}}>
          <div style={{...wheelStyle, left: '10px'}}></div>
          <div style={{...wheelStyle, right: '10px'}}></div>
          <div style={{...wheelStyle, left: '10px', bottom: '30px'}}></div>
          <div style={{...wheelStyle, right: '10px', bottom: '30px'}}></div>
          <div style={headlightStyle(false)}></div> {/* Правая фара */}
        </div>
      </div>
      
      {/* Красный автомобиль (движется влево) */}
      <div style={redCarStyle}>
        <div style={{...baseCarStyle, backgroundColor: 'red', borderRadius: '5px'}}>
          <div style={{...wheelStyle, left: '10px'}}></div>
          <div style={{...wheelStyle, right: '10px'}}></div>
          <div style={{...wheelStyle, left: '10px', bottom: '30px'}}></div>
          <div style={{...wheelStyle, right: '10px', bottom: '30px'}}></div>
          <div style={headlightStyle(true)}></div> {/* Левая фара */}
        </div>
      </div>
    </div>
  );
}

export default App;